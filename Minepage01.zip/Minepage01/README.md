# Portfolio
My website portfolio

## Screenshots:
### Computer View
![alt text](https://github.com/alisolanki/Portfolio/blob/master/Portfolio.PNG)

### Mobile View
![alt text](https://github.com/alisolanki/Portfolio/blob/master/Portfolio_mobile.PNG)

## Author
* Mohd. Ali Solanki (https://youtube.com/AliSolanki)
